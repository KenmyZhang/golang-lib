// Package contrib is the GoCV wrapper around OpenCV Contrib.
//
// For further details, please see:
// https://github.com/opencv/opencv_contrib
//
package contrib // import "gocv.io/x/gocv/contrib"
