echo "This script is no longer necessary and has been deprecated."
echo "See the Custom Environment section of the README if you need to customize your environment."
