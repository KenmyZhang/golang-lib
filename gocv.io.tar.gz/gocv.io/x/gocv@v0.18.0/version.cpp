#include "version.h"

const char* openCVVersion() {
    return CV_VERSION;
}
