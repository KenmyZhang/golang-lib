#ifndef _GOCVOPENVINO_IE_H_
#define _GOCVOPENVINO_IE_H_

#ifdef __cplusplus
#include <inference_engine.hpp>
extern "C" {
#endif

#ifdef __cplusplus
#else
#endif

const char* OpenVinoVersion();

#ifdef __cplusplus
}
#endif

#endif //_GOCVOPENVINO_IE_H_
