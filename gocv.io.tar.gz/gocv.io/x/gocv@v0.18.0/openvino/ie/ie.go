// Package ie is the GoCV wrapper around the Intel OpenVINO toolkit's
// Inference Engine.
//
// For further details, please see:
// https://software.intel.com/en-us/openvino-toolkit
//
package ie // import "gocv.io/x/gocv/openvino/ie"
